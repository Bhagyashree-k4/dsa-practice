
package com.gs.dsa.arrays;

import java.util.*;

/**
 * Variants: first valid pair (hashmap), smallest indices (lexicographic), largest indices.
 * Expected: O(n) for first; others can pre-index positions.
 */
public final class TwoSumVariants {
    private TwoSumVariants() {
    }

    /**
     * TODO: First valid pair using hashmap.
     */
    public static int[] twoSumFirst(int[] nums, int target) {

        Map<Integer, Integer> complement = new HashMap<>();

        for (int i = 0; i < nums.length; i++) {

            if (complement.containsKey(target - nums[i])) {
                return new int[]{complement.get(target - nums[i]), i};
            } else complement.put(nums[i], i);
        }

        return new int[]{-2, -2};
    }

    /**
     * TODO: Lexicographically smallest index pair.
     */
    public static int[] twoSumSmallestIndices(int[] nums, int target) {

        Map<Integer, Integer> complement = new HashMap<>();
        int resultx = Integer.MAX_VALUE;

        for (int i = 0; i < nums.length; i++) {

            if (complement.containsKey(target - nums[i])) {
                if (resultx > i) resultx = i;
                if (resultx > complement.get(target - nums[i])) resultx = complement.get(target - nums[i]);
            }

            complement.put(nums[i], i);
        }

        return new int[]{resultx, complement.get(target - nums[resultx])};
    }


    /**
     * TODO: Lexicographically largest index pair.
     */
    public static int[] twoSumLargestIndices(int[] nums, int target) {

        Map<Integer, Integer> complement = new HashMap<>();
        int resultx = Integer.MIN_VALUE;

        for (int i = 0; i < nums.length; i++) {

            if (complement.containsKey(target - nums[i])) {
                if (resultx < i) resultx = i;
                if (resultx < complement.get(target - nums[i])) resultx = complement.get(target - nums[i]);
            }

            complement.put(nums[i], i);
        }

        return new int[]{complement.get(target - nums[resultx]), resultx};
    }
}
