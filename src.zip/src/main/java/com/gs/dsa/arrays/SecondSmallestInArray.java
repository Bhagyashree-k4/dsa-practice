
package com.gs.dsa.arrays;

/**
 * Find second smallest distinct value in one pass.
 * Edge cases: duplicates, all equal, fewer than 2 distinct values.
 */
public final class SecondSmallestInArray {
    private SecondSmallestInArray() {}
    /** TODO: Implement single-pass tracking of min and second min. */
    public static int secondSmallest(int[] nums) {
        if (nums == null || nums.length < 2) {
            throw new IllegalArgumentException("Array must have at least two elements");
        }

        int min = Integer.MAX_VALUE;
        int second = Integer.MAX_VALUE;

        for (int num : nums) {
            if (num < min) {
                second = min;
                min = num;
            } else if (num > min && num < second) {
                second = num;
            }
        }
        if (second == Integer.MAX_VALUE) {
            throw new IllegalArgumentException("No second distinct smallest value found");
        }

        return second;
    }
}
