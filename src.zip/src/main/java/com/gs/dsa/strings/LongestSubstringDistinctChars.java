
package com.gs.dsa.strings;

import java.util.HashSet;
import java.util.Set;

/**
 * Length of longest substring with all distinct characters (sliding window).
 * Edge cases: empty, repeated clusters, large alphabets.
 */
public final class LongestSubstringDistinctChars {
    private LongestSubstringDistinctChars() {}
    /** TODO: Implement O(n) sliding window with last-seen positions. */
    public static int lengthOfLongestDistinct(String s) {

        int left = 0, start =0;
        int result = 0;
        Set<Character> unique = new HashSet<>();
        while(left < s.length()){
            if(!unique.contains(s.charAt(left))){
                unique.add(s.charAt(left));
                left++;
            }
            else{
                result = Math.max(result, left - start);
                while (s.charAt(start) != s.charAt(left)) {
                    unique.remove(s.charAt(start++));
                }
                unique.remove(s.charAt(start++));
            }
        }
        result = Math.max(result, left - start);
        return result;
    }
}
